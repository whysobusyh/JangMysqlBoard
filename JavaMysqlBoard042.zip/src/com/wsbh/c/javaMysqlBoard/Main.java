package com.wsbh.c.javaMysqlBoard;

public class Main {
	public static void main(String[] args) {
		ProcMenu procmenu = new ProcMenu();
		procmenu.run();
		
	}
}
