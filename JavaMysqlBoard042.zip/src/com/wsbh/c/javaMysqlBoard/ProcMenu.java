package com.wsbh.c.javaMysqlBoard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
/*	이전 수행 항목
 *  글 삭제기능 추가
 *  글 리스트업
 */

/*	Todo
 * 	글 수정기능 추가
 */

public class ProcMenu {
	ResultSet result = null;
	Scanner sc = new Scanner(System.in);
	Statement st = null;

	void run() {
		Display.showMainMenu();
		Display.showTitle();
		dbrun();
		procMenu();
	}

	void dbrun() {
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
//			ResultSet result = st.executeQuery("select*from totmember where no=7");
//			while(result.next()){
//				String name = result.getString("name");
//				System.out.println(name);
//			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	void procMenu() {
		int menuList = sc.nextInt();
		sc.nextLine();
		switch (menuList) {
		case 1:
			listArticle();
			run();
			break;
		case 2:
			findArticle();
			run();
			break;
		case 3:
			writeArticle();
			run();
			break;
		case 4:delArticle();
			run();
			break;
		case 0:
			updateArticle();
			run();
			break;
		default:
			System.out.println("잘못 입력하셨습니다. 초기화면으로 돌아갑니다.");
			run();
			break;
		}
	}

	void writeArticle() {
		System.out.println("제목을 입력해주세요");
		sc.nextLine();
		String title = sc.nextLine();
		System.out.println("글 내용을 입력해주세요");
		String text = sc.nextLine();
		System.out.println("id를 입력해주세요");
		String id = sc.nextLine();
		try {
			st.executeUpdate(
					"insert into board (b_title,b_text,b_id) values ('" + title + "','" + text + "', '" + id + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	void findArticle() {
		try {
			System.out.println("찾으시는글을 입력해주세요");
			
			String find = sc.nextLine();
			result = st.executeQuery("select*from board where b_title = '" + find + "' ");
			while (result.next()) {
				String ftitle = result.getString("b_title");
				String ftext = result.getString("b_text");
				String fid = result.getString("b_id");
				System.out.println("제목 : " + ftitle);
				System.out.println("내용 : " + ftext);
				System.out.println("작성자 : " + fid);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	void delArticle() {
		try {
			System.out.println("제거할려는 글 제목을 입력해주세요");
			sc.nextLine();
			String delTitle = sc.nextLine();
			result = st.executeQuery("select*from board where b_title = '" + delTitle + "'");
			while(result.next()) {
				String ftitle = result.getString("b_title");
				String ftext = result.getString("b_text");
				String fid = result.getString("b_id");
				System.out.println("제목 : " + ftitle);
				System.out.println("내용 : " + ftext);
				System.out.println("작성자 : " + fid);
			}
			System.out.println("글을 삭제하시겠습니까? 1.y / 2.n \n 현재 버전에서는 출력된 글 전부가 삭제됩니다.");
			int tf = sc.nextInt();
			switch(tf) {
			case 1: 
				st.executeUpdate("delete from board where b_title = '"+delTitle+"'");
				System.out.println("전부 삭제되었습니다.");
				break;
			case 2:
				System.out.println("삭제츨 취소하고 초기화면으로 돌아갑니다.");
				run();
				break;
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	void listArticle() {
		try {
			result = st.executeQuery("select*from board");
			while(result.next()) {
				int no = result.getInt("b_no");
				String ftitle = result.getString("b_title");
				String fid = result.getString("b_id");
				System.out.printf("글 번호 : %d 글 제목 : %s 작성자 : %s \n",no,ftitle,fid);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	void updateArticle() {
	    listArticle();
	    System.out.println("글 번호를 입력해주세요");
	    int no = sc.nextInt();
	    sc.nextLine(); // 개행 문자 소비
	    try {
	        result = st.executeQuery("select * from board where b_no = '" + no + "'");
	        System.out.println("수정하실 내용을 입력해주세요");
	        String text = sc.nextLine();
	        st.executeUpdate("update board set b_text = '" + text + "' where b_no = '" + no + "'");
	        System.out.println("글이 수정되었습니다.");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
}
